<?php
include '../db.php';
 
$sid=$_GET['pid'];
$_SESSION['sid']=$sid;

echo $sid;


 
 
	
	$sql="select * from registration where id='$sid' "; 
										$re = mysqli_query($conn,$sql);
										
										while($row = mysqli_fetch_array($re))
										{
									       $name=$row['name'];
									       $email=$row['email'];
										   $ticket=$row['ticket'];
										}
							echo $name;
							echo $email;
							echo $ticket;
 	
$to = $email;
$subject = "CodeFiesta Confirmation Mail";
$txt = "Hello ".$name.",\n Thank you for registering for  ".$ticket.". You're registration has been received. We hope to see you on 11th January. \n All the best. \n \n Regards, \n Team CodeFiesta. \n codefiesta@moderncoe.edu.in \n Pratik - 9762509395 \n\n";
 
$headers = "From: codefiesta@moderncoe.edu.in" ;

if(mail($to,$subject,$txt,$headers))
{
 echo "<script>alert('Mail Sent successfully');</script>";
  echo "<script>window.location.href='../payments/hmm.php'</script>"; 
}
else
{
  echo "<script>alert('Try again');</script>";
  echo "<script>window.location.href='../payments/hmm.php'</script>"; 
}
 
 


?>
 
