<?php session_start();
if(!isset($_SESSION['nm'])) { header('location:index.php'); exit;}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css"></script>
   
</head>
<body>

<div class="container">
  <h2>List</h2>
    
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Sr.No</th>
				<th>Name</th>
				<th>Email</th>
				<th>Contact</th>
				<th>Event Name</th>
				<th>College Name</th>
                                <th>Date & Time</th>
				<th>Transaction ID</th>
				<th>Confirm</th>
            </tr>
        </thead>
        <tbody>
            <?php   include '../db.php';
 $sql="select * from registration";
										$re = mysqli_query($conn,$sql);
										while($row = mysqli_fetch_array($re))
										{
										echo"<tr>
													 
													<td>".$row['id']."</td>
													<td>".$row['name']."</td>
													<td>".$row['email']."</td>
													<td>".$row['contact']."</td>
													<td>".$row['ticket']."</td>
													<td>".$row['college']."</td>
                                                                                                        <td>".$row['timestamp']."</td>
													<td>".$row['transaction_id']."</td>
													<td><a href=dbconfirm.php?pid=".$row['id']." > Confirm</td>
													 
														     
												 
													</tr>";
										 
										}
											?>
  </table>
</div>
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
  
</body>
</html>
