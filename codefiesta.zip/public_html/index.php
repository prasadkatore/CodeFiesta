<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>CodeFiesta</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/pl.ico"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">

    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    <!-- Fonts -->

    <!-- Open Sans for body font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700,800" rel="stylesheet">
	<!-- Montserrat for title -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
 
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  	
  	<!-- Start Header -->
	<header id="mu-hero" class="" role="banner">
		<!-- Start menu  -->
		<nav class="navbar navbar-fixed-top navbar-default mu-navbar">
		  	<div class="container">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>

			      <!-- Logo -->
			      <a class="navbar-brand" href="index.html">CodeFiesta</a>

			    </div>

			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      	<ul class="nav navbar-nav mu-menu navbar-right">
			      		<li><a href="#mu-hero">Home</a></li>
				        <li><a href="#mu-about">About Us</a></li>
				        <li><a href="#mu-event">Event</a></li>
				      
				        <li><a href="#mu-schedule">Schedule</a></li>
						  <li><a href="#mu-faq">Previous Year</a></li>
			            <li><a href="#mu-pricing">Sponsors</a></li>
			            <li><a href="gallery.html" target="_blank">Gallery</a></li>
			            <li><a href="#mu-register">Register</a></li>
			           
			            <li><a href="#mu-venue">Contact Us</a></li>
			      	</ul>
			    </div><!-- /.navbar-collapse -->
		  	</div><!-- /.container-fluid -->
		</nav>
		<!-- End menu -->

		<div class="mu-hero-overlay">
			<div class="container">
				<div class="mu-hero-area">

					<!-- Start hero featured area -->
					<div class="mu-hero-featured-area">
						<!-- Start center Logo --><center><img src="logo.png" alt="Brand Logo" height="170px" width="140px"></center>
						<div class="mu-logo-area">
							<!-- text based logo -->
						
											<!--img src="logo.png" alt="Brand Logo" height="200px" width="200px"-->
									
							<a class="mu-logo" href="#">P.E.S MODERN COLLEGE OF ENGINEERING,PUNE</a>
							<!-- image based logo -->
							<!-- <a class="mu-logo" href="#"><img src="assets/images/logo.jpg" alt="logo img"></a> -->
						</div>
						<!-- End center Logo -->

						<div class="mu-hero-featured-content">

							<h1>WELCOME TO CODEFIESTA 2019</h1>
							<h2>The Biggest Technical Event in Computer Department</h2>
							<p class="mu-event-date-line">12<sup>th</sup> January, 2019</p>

							<div class="mu-event-counter-area">
								<div id="mu-event-counter">
									
								</div>
							</div>

						</div>
					</div>
					<!-- End hero featured area -->

				</div>
			</div>
		</div>
	</header>
	<!-- End Header -->
	
	<!-- Start main content -->
	<main role="main">
		<!-- Start About -->
		<section id="mu-about">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-about-area">
							<!-- Start Feature Content -->
							<div class="row">
								<div class="col-md-6">
									<div class="mu-about-left">
										<img class="" src="pl.png" alt="Men Speaker" height="450px">
									</div>
								</div>
								<div class="col-md-6">
									<div class="mu-about-right">
										<h2>About CodeFiesta</h2>
										<p>M-Pulse is an annual technical event of P.E.S’s Modern College of Engineering. CodeFiesta
                                           being the Computer Engineering Department division of M-Pulse. </p>
										<p>Ever since M-Pulse was initiated in 2006, the technomanagement event of the college has grown in size,
name and grandeur. We have worked hard over this
period to raise the benchmark each year to deliver more
than what was expected from us. Apart from taking a
classy turn this year, we present you with a much more
technically enriched event by introducing CodeFiesta
2019.
</p>
										<p>Four technical events/competitions will be organised
under CodeFiesta where 250+ students are expected to
participate from number of renowned Engineering
colleges spread over Pune. Our agenda is to provide a
platform where students/participants get opportunities to
showcase their talent and technical skills.So join us as we take this giant leap into CodeFiesta
2019.<br>
<a href="gallery.html" target="_blank">View Gallery</a>

</p>
										</div>
								</div>
							</div>
							<!-- End Feature Content -->

						</div>
					</div>
				</div>
				
				
				
				
			</div>
		</section>
		<!-- End About -->

		
		<section id="mu-event">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-event-area">
							<div class="row">
					<div class="colo-md-12">
						<div class="mu-schedule-area">

							<div class="mu-title-area">
								<h2 class="mu-title">Our Events</h2>
							</div>

							<div class="mu-schedule-content-area">
								<!-- Nav tabs -->
								<ul class="nav nav-tabs mu-schedule-menu" role="tablist">
								    <li role="presentation" class="active"><a href="#first-day1" aria-controls="first-day" role="tab" data-toggle="tab">Tech Wizard</a></li>
								    <li role="presentation"><a href="#second-day1" aria-controls="second-day" role="tab" data-toggle="tab">Pro Googler</a></li>
								    <li role="presentation"><a href="#third-day1" aria-controls="third-day" role="tab" data-toggle="tab">Crack'it</a></li>
								    <li role="presentation"><a href="#fourth-day1" aria-controls="fourth-day" role="tab" data-toggle="tab">Maze Coders</a></li>
								    
								</ul>

								<!-- Tab panes -->
								<div class="tab-content mu-schedule-content">
								    <div role="tabpanel" class="tab-pane fade mu-event-timeline in active" id="first-day1">
								    	<div class="col-md-12">
											<div class="mu-single-price mu-popular-price">
												 
												 
												<h3 class="mu-price-title"><u>Tech Wizard</u></h3>
												 <p>
												 This event takes the participants on a journey testing his skills on all broad domains of technology, from general knowledge about languages, to coding a program in the basic language.
												 <br><br>
												<u><b>ROUND 1</b></u><br>

All MCQ's will be on programming languages.Time limit is 15 minutes.<br>

<u><b>Round 2</b></u><br>
This will be the coding round,it can be done in any language.Test cases will be given through which the participant has to code a program according to the problem statement. The problem statement will be hidden in a directory, whose location has to be found by the participant from a given clue. Fastest and efficient code qualifies. Time limit is 20 minutes.<br>
 
<u><b>Registration fees</u></b><br> Individual: ₹ 50 <br> Team of 2: ₹ 90 
												</p>
												 
											</div>
									    </div>
								    </div>
								    <div role="tabpanel" class="tab-pane fade mu-event-timeline" id="second-day1">
								    	 <div class="col-md-12">
											<div class="mu-single-price mu-popular-price">
												 
												 
												<h3 class="mu-price-title"><u>Pro Googler</u></h3>
												 <p>
												A set of random questions are provided which are to be resolved by firing appropriate queries on Google. The event is mainly based on what we call the art of Googling using various search patterns. This is one event which will really depict the power of The Internet.
												<br><br>
												<u><b>ROUND 1</b></u><br>

In Round 1, participants will be given a number of questions and these questions have to be answered within the given time limit. Participants have to answer maximum questions within the time.<br>

<u><b>Round 2</b></u><br>
There is a twist in the round 2, the time will be given and the participants have to answer the question within that time.<br>
<u><b>Registration fees</u></b><br> Per head: ₹ 60  
												</p>
												 
											</div>
									    </div>
								    </div>
								    <div role="tabpanel" class="tab-pane fade mu-event-timeline" id="third-day1">
								    	   <div class="col-md-12">
											<div class="mu-single-price mu-popular-price">
												 
												 
												<h3 class="mu-price-title"><u>Crack'it</u></h3>
												 <p>
												  Do you like logo quiz, trivia games? Do you think you know companies from all over the world? Do you think you know about trending movies? Crack’it is just for you! Embark upon the interesting journey with a logo quiz and move towards your favourite TV trivia.
												<br><br>
												<u><b>ROUND 1</b></u><br>

In Round 1, the participants will be appearing for 4 levels containing 20 logos each. Name of the logo should be provided within the given time limit. Participants have to answer maximum questions within the 15 minutes.<br>

<u><b>Round 2</b></u><br>
In Round 2,the participants will have to solve the mcq’s on trending topics in a given time limit. Time limit is 10 minutes.<br>
<u><b>Registration fees</u></b><br> Individual: ₹ 50 <br> Team of 2: ₹ 90 
												</p>
												 
											</div>
									    </div>
								    </div>
									<div role="tabpanel" class="tab-pane fade mu-event-timeline" id="fourth-day1">
								    	   <div class="col-md-12">
											<div class="mu-single-price mu-popular-price">
												 
												 
												<h3 class="mu-price-title"><u>Maze Coders</u></h3>
												 <p>
												   You think you are good at handling the Linux File System ? Give it a try !! Play Hangman with technical keywords in the first round and find the hidden clues from Linux File System in second round and solve the problem to win.
												<br><br>
												<u><b>ROUND 1</b></u><br>

The participants play a Hangman game to find the hint and clear the first round.<br>

<u><b>Round 2</b></u><br>
Clues in the form of files will be hidden in the Linux File System and you will have to traverse through the files to get the final clue and solve the problem.<br>
<u><b>Registration fees</u></b><br> Per head: ₹ 50  
												</p>
												 
											</div>
									    </div>
								    </div>
								    
								</div>

							</div>
							
						</div>
					</div>
				</div>
						</div>
					</div>
				</div>
			</div>
		</section>			 

		<!-- Start Schedule  -->
		<section id="mu-schedule">
			<div class="container">
				<div class="row">
					<div class="colo-md-12">
						<div class="mu-schedule-area">

							<div class="mu-title-area">
								<h2 class="mu-title">Schedule Detail</h2>
							
							</div>

							<div class="mu-schedule-content-area">
								<!-- Nav tabs -->
								<ul class="nav nav-tabs mu-schedule-menu" role="tablist">
								    <li role="presentation" class="active"><a href="#first-day" aria-controls="first-day" role="tab" data-toggle="tab"> 12<sup>th</sup> January</a></li>
								    
								</ul>

								<!-- Tab panes -->
								<div class="tab-content mu-schedule-content">
								    <div role="tabpanel" class="tab-pane fade mu-event-timeline in active" id="first-day">
								    	<ul>
								    		<li>
								    			<div class="mu-single-event">
								    				<p class="mu-event-time">10.30 AM</p>
								    				<h3>Inauguration</h3>
								    			</div>
								    		</li>
								    		<li>
								    			<div class="mu-single-event">
								    				 
								    				<p class="mu-event-time">11.30 AM</p>
								    				<h3>Event 1 - Round 1</h3>
								    				<h3>Event 2 - Round 1</h3>
								    				 
								    			</div>
								    		</li>
								    		<li>
								    			<div class="mu-single-event">
								    				 
								    				<p class="mu-event-time">12.00 AM</p>
								    				<h3>Event 3 - Round 1</h3>
								    				<h3>Event 4 - Round 1</h3>
								    			 
								    			</div>
								    		</li>
								    		 
								    		<li>
								    			<div class="mu-single-event">
								    				<p class="mu-event-time">1.00 - 01:30 PM</p>
								    				<h3>Break</h3>
								    			</div>
								    		</li>
											
											<li>
								    			<div class="mu-single-event">
								    				 
								    				<p class="mu-event-time">01:30 PM</p>
								    				<h3>Event 1 - Round 2</h3>
								    				<h3>Event 2 - Round 2</h3>
								    			 
								    			</div>
								    		</li>
											
											<li>
								    			<div class="mu-single-event">
								    				 
								    				<p class="mu-event-time">02.00 PM</p>
								    				<h3>Event 3 - Round 2</h3>
								    				<h3>Event 4 - Round 2</h3>
								    				 
								    			</div>
								    		</li>
											
											<li>
								    			<div class="mu-single-event">
								    				<p class="mu-event-time">3 PM</p>
								    				<h3>Felicitation / End</h3>
								    			</div>
								    		</li>
								    	</ul>
								    </div>
								   
								    
								    
								</div>

							</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Schedule -->

		<!-- Start FAQ -->
		<section id="mu-faq">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-faq-area">

							<div class="mu-title-area">
								<h2 class="mu-title">Previous Year CodeFiesta</h2>
								<p>CodeFiesta is a technical event organized by the Computer Department of P.E.S. Modern College of Engineering, Shivaji Nagar, Pune. 

This event has been running for three years now. Each year students from the Computer Department try to outdo the previous year with better competitions, management & the entertainment factor.</p>
							</div>

							<div class="mu-faq-content">

								<div class="panel-group" id="accordion">

							        <div class="panel panel-default">
							          <div class="panel-heading">
							            <h4 class="panel-title">
							              <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true">
							                <span class="fa fa-angle-down"></span> CodeFiesta 2018
							              </a>
							            </h4>
							          </div>
							          <div id="collapseOne" class="panel-collapse collapse in">
							            <div class="panel-body">
                                              CodeFiesta 2018 brought various tournaments for students from many different colleges in Pune. These included ‘Tech Wizard’, ‘Pro-Googler’, ‘Maze Coders’, ‘Crack it’.

 

The tournaments were developed entirely from scratch by the students of the computer department. Every tournament tested diverse technical skills of the participants ranging from logical analysis, Linux directory handling, command line to actual coding in C, C++, Java & Python. <br> Participants incorporated their presence of mind and dexterity with their problem solving skills to achieve ranks in the tournaments. They needed to take a problem given on the spot to a solution in as less time as possible. Thus by reaping the benefits of competition they got a platform to boast their coding abilities.

 

With upwards of 350 participants vigorously competing to prove their technical prowess CodeFiesta was very successful bringing a promise of a much bigger and better event in the forthcoming years.							           
									   </div>
									   
									   
									   
								<div class="row">
								
									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="10.jpg" alt="Armour Antivirus">
										</div>
									</div>

									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="8.png" alt="Summet Group">
										</div>
									</div>

									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="3.jpg" alt="C.S.I">
										</div>
									</div>

									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="2.png" alt="Mirhae">
										</div>
									</div>

									 

									 

								</div>
							 
									   
									   
									   
							          </div>
							        </div>

							        <div class="panel panel-default">
							          <div class="panel-heading">
							            <h4 class="panel-title">
							              <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
							                <span class="fa fa-angle-up"></span> CodeFiesta 2017
							              </a>
							            </h4>
							          </div>
							          <div id="collapseTwo" class="panel-collapse collapse">
							            <div class="panel-body">
											CodeFiesta 2017 had ‘Allied Force Coding’, ‘Pro-Googler’, ‘Maze Coders’.

 

The tournaments were developed entirely from scratch by the students of the computer department. Every tournament tested diverse technical skills of the participants ranging from logical analysis, Linux directory handling, command line to actual coding in C, C++, Java & Python. Participants incorporated their presence of mind and dexterity with their problem solving skills to achieve ranks in the tournaments. They needed to take a problem given on the spot to a solution in as less time as possible. 

 

With upwards of 350 participants vigorously competing to prove their technical prowess CodeFiesta was very successful bringing a promise of a much bigger and better event in the forthcoming years.

									   </div>
									   
									   <div class="row">
								
									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="1.png" alt="Riser Techhub">
										</div>
									</div>

									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="2.png" alt="Mirhae">
										</div>
									</div>

									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="3.jpg" alt="C.S.I">
										</div>
									</div>

									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="4.jpg" alt="Bank Edge">
										</div>
									</div>

										<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="5.jpg" alt="Softronikx">
										</div>
									</div>

									<div class="col-md-2 col-sm-4 col-xs-4">
										<div class="mu-sponsors-single">
											<img src="6.jpg" alt="Matrix Infra">
										</div>
									</div>

									 

								</div>
									   
							          </div>
							        </div>

							      
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End FAQ -->

		<!-- Start Pricing  -->
		<section id="mu-pricing">
			<div class="container">
			   
			
				<div class="row">
				
				    <div class="col-md-12">
						<div class="mu-sponsors-area">
							
							 
							
							 

						</div>
					</div>
				
					<div class="col-md-12">
						<div class="mu-pricing-area">
							
							<div class="mu-title-area">
								<h2 class="mu-title">Sponsorship plans</h2>
							</div>
							
							<div class="mu-pricing-conten">
								<div class="row">
									
									<!-- single price item -->
									<div class="col-md-4">
										<div class="mu-single-price">

											<div class="mu-single-price-head">
												<span class="mu-currency">₹</span>
												<span class="mu-rate">48,000</span>
												 
											</div>
											<h3 class="mu-price-title">PLATINUM</h3>
											<ul>
												<li>Title Sponsorship</li>
												<li>4 Events Sponsorship</li>
												<li>6 Banners</li>
												<li>Watermark on certificate</li>
												<li>Social media,Android App & Website Publicity</li>
												<li>Internships</li>
												<li>Invitation as a judge in state level project competition</li>
											</ul>
											 
										</div>
									</div>
									<!-- / single price item -->
								<!-- single price item -->
									<div class="col-md-4">
										<div class="mu-single-price mu-popular-price">
											<span class="mu-price-tag">Popular</span>
											<div class="mu-single-price-head">
												<span class="mu-currency">₹</span>
												<span class="mu-rate">37,000</span>
												 
											</div>
											<h3 class="mu-price-title">GOLD</h3>
											<ul>
												<li>3 Events Sponsorship</li>
												<li>4 Banners</li>
												<li>Logo on certificate</li>
												<li>Social media,Android App & Website Publicity</li>
												<li>Invitation as a judge in state level project competition</li>
												<li><br></li>
												<li><br></li>
											</ul>
											 
										</div>
									</div>
									<!-- / single price item -->

									<!-- single price item -->
									<div class="col-md-4">
										<div class="mu-single-price">

											<div class="mu-single-price-head">
												<span class="mu-currency">₹</span>
												<span class="mu-rate">25,000</span>
												 
											</div>
											<h3 class="mu-price-title">SILVER</h3>
											<ul>
												<li>2 Events Sponsorship</li>
												<li>3 Banners</li>
												<li>Logo on certificate</li>
												<li>Social media,Android App & Website Publicity</li>
												<li><br></li>
												<li><br></li>
												<li><br></li>
											</ul>
											 
										,</div>
									</div>
									<!-- / single price item -->

								</div>
							</div>
							
							<div class="mu-pricing-conten">
								<div class="row">
									
									<!-- single price item -->
									<div class="col-md-4">
										<div class="mu-single-price">

											<div class="mu-single-price-head">
												<span class="mu-currency">₹</span>
												<span class="mu-rate">15,000</span>
												 
											</div>
											<h3 class="mu-price-title">BRONZE</h3>
											<ul>
												<li>1 Events Sponsorship</li>
												<li>2 Banners</li>
												<li>Logo on certificate</li>
												<li>Social media,Android App & Website Publicity</li>
												 
											</ul>
											 
										</div>
									</div>
									<!-- / single price item -->

									<!-- single price item -->
									<div class="col-md-4">
										<div class="mu-single-price mu-popular-price">
											<span class="mu-price-tag">Popular</span>
											<div class="mu-single-price-head">
												<span class="mu-currency">₹</span>
												<span class="mu-rate">25,000</span>
											 
											</div>
											<h3 class="mu-price-title">T-SHIRT SPONSORSHIP</h3>
											<ul>
												<li>Company logo on the Sleeves of all &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; t-shirts</li>
												<li><br></li>
												<li><br></li>
												<li><br></li>
											</ul>
											 
										</div>
									</div>
									<!-- / single price item -->

									<!-- single price item -->
									<div class="col-md-4">
										<div class="mu-single-price">

											<div class="mu-single-price-head">
												<span class="mu-currency"><br></span>
												<span class="mu-rate"></span>
												 
											</div>
											<h3 class="mu-price-title">BANNERS</h3>
											<ul>
												<li>3 Banners = ₹3000/-</li>
												<li>2 Banners = ₹2700/-</li>
												<li>1 Banners = ₹1500/-</li>
												<li><br></li>
												<li><br></li>
												<li><br></li> 
											</ul>
											 
										</div>
									</div>
									<!-- / single price item -->

								</div>
								
								
							</div>

						</div>
					</div>
				</div>
			</div>
			
			
			
		</section>
		<!-- End Pricing -->
		
		
		<!-- Start Register  -->
		<section id="mu-register">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-register-area">

							<div class="mu-title-area">
								<h2 class="mu-title">Registeration Form</h2>
							</div>

							<div class="mu-register-content">
								<form class="mu-register-form" action="payment.php" method="post">

									<div class="row">
										<div class="col-md-6">
											<div class="form-group">                
												<input type="text" class="form-control" placeholder="Your Full Name" id="name" name="name" required="">
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group">                
												<input type="email" class="form-control" placeholder="Enter Your Email" id="email" name="email" required="">
											</div>     
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="form-group">                
												 <input type="tel" class="form-control" pattern="^\d{10}$" maxlength="10" placeholder="Your Phone Number" name="telephone" required>
											</div>
										</div>
										<div class="col-md-6">
											
										<div class="form-group"> 
											<select class="form-control" name="ticket" id="ticket" required="">
												<option value="0">--- Select Event ---</option>
												<option value="Tech Wizard solo">Tech Wizard (Solo) -- Price-50₹  </option>
<option value="Tech Wizard duo">Tech Wizard (Duo 2 members) -- Price-90₹  </option>
												
												<option value="Pro Googler">Pro Googler (Solo) -- Price-60₹  </option>
												<option value="Crack it">Crack'it (Solo) -- Price-50₹ </option>
												<option value="Maze Coders solo">Maze Coders (Solo)-- Price-50₹</option>
<option value="Maze Coders duo">Maze Coders (Duo 2 members) -- Price-90₹</option>
											</select>
										</div>      
										</div>
									</div>
									
									<div class="row">
									<div class="col-md-12">
											<div class="form-group">                
												<input type="text" class="form-control" placeholder="Your College Name" id="college" name="college" required="">
											</div>
										</div>
									</div>

									<button type="submit" class="mu-reg-submit-btn">SUBMIT</button>

					            </form>
							</div>

						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Register -->

		
		<!-- Start Venue -->
		<section id="mu-venue">
			<div class="mu-venue-area">
				<div class="row">

					<div class="col-md-6">
						<div class="mu-venue-map">
							<iframe src="https://www.google.com/maps/embed/v1/place?q=PES%20modern%20college%20of%20engineering%20pune&key=AIzaSyApt3CVg6PyajQ2lHslEyrS-InvOOFNnNs" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
						</div>
					</div>

					<div class="col-md-6">
						<div class="mu-venue-address">
							<h2>Contact Us &nbsp;<i class="fa fa-chevron-right" aria-hidden="true"></i></h2>
							<h3>PES Modern College of Engineering</h3>
							<h4>1186/A, Off J.M. Road, Shivaji nagar, Pune, Maharashtra 411005</h4>
							<p>Contact No.-</p>
							<p> Sandeep Chavan  (+91-9552873557)</p>
							<p> Harshil Doshi  (+91-9763982581)</p>
							 
						</div>
					</div>

				</div>
			</div>
		</section>
		<!-- End Venue -->

		

		 
		<!-- Start Contact -->
		
		<!-- End Contact -->

	</main>
	
	<!-- End main content -->	
			
			
	<!-- Start footer -->
	<footer id="mu-footer" role="contentinfo">
			<div class="container">
				<div class="mu-footer-area">
					<div class="mu-footer-top">
						<div class="mu-social-media">
							<a target="_blank" href="https://m.facebook.com/mpulse.codefiesta"><i class="fa fa-facebook"></i></a>
						    <a target="_blank" href="https://instagram.com/mpulse_codefiesta?utm_source=ig_profile_share&igshid=31jcgvbgkuaj"><i class="fa fa-instagram"></i></a>
						</div>
					</div>
					<div class="mu-footer-bottom">
						<p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="http://markups.io">PES Modern College of Engineering,Pune</a>. All right reserved.</p>
					</div>
				</div>
			</div>

	</footer>
	<!-- End footer -->

	
	
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
	<!-- Slick slider -->
    <script type="text/javascript" src="assets/js/slick.min.js"></script>
    <!-- Event Counter -->
    <script type="text/javascript" src="assets/js/jquery.countdown.min.js"></script>
    <!-- Ajax contact form  -->
    <script type="text/javascript" src="assets/js/app.js"></script>
  
       
	
    <!-- Custom js -->
	<script type="text/javascript" src="assets/js/custom.js"></script>

	
	
    
  </body>
</html>